LifeOS Übungslexikon – Zwischenversion

Neu: anatomische schematische Vorder-/Rückansichten, Haupt-/Hilfsmuskeln in der Übungsdetailansicht für die vorhandenen 60 Übungen. Die ursprünglichen Übungs-IDs, Trainingsfunktionen und localStorage-Key lifeos-v1 bleiben erhalten.

Wichtig: Echte Übungsfotos sind noch NICHT eingebaut. Für die Fotos ist eine einzelne Prüfung der Nutzungsrechte erforderlich. Die Karten sind schematisch und Zuordnungen vorläufig.

Installation: index.html in GitHub-Repository hochladen und bestehende Datei ersetzen. Vorher ggf. JSON-Daten exportieren. Nach dem Upload testen.

JavaScript-Syntax geprüft; keine vollständigen Browser-Funktionstests.
