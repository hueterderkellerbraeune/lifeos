LifeOS Monatsplan v9 – Satzfortschritt und schnelles Abhaken. ZIP entpacken und index.html im GitHub-Repository ersetzen. Vorher Daten exportieren.
